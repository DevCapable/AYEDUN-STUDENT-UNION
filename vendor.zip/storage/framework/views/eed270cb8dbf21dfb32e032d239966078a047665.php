<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>User | Dashboard</title>
	<?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<style>
		.help-block {
			color: #dc3545;
		}

		.has-error {
			color: #dc3545;
		}

		.card:hover {
            box-shadow: 0px 2px 7px 2px gray ;
        }
	
		body {
			font-family: Arial;
		}

		
	</style>
</head>

<body style="padding-top: 100px">
	<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
			</div>
			<div class="col-sm-6">
				<form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
					<button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
							style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
							Picture</a></button>
				</form>
				<form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
					<?php echo csrf_field(); ?>
					<button style=" float: right;" type="submit" class="btn btn-sm btn-primary">Log Out</button>
				</form>
			</div>
		</div>
		<div class="row mt-12">
			<div class="col-md-12 offset-col-md-4">
				<div class="card">
					<div class="card-header">
                        <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder"><?php echo e(strtoupper($UserId->full_name)); ?>'S PROFILE</h4>
					</div>
					<div class="card-body">
						<div class="row">
							<div class="col-sm-6">
								<section class="blog-page">
									<div class="container">
										<div class="row">
											<div class="col-md-10 col-md-offset-2">
												<div class="blog-item"> <div>
													<span style="float: left"
													class="badge badge-info pull-right">From (<?php echo e($UserId->year_of_tenure_from); ?>) To (<?php echo e($UserId->year_of_tenure_to); ?>)
												</span><br>
												</div>
													<div class="down-content">

														<div class="row">
															<details>
																<summary style="background-color:red; color:#fff;">
																	...Click to See <i class="fa fa-eye"></i>
																	 <?php echo e($UserId->full_name); ?> s' Profile
																</summary>
																<table class="table"
																	style="padding-left: 20px; margin-left: 30px;">
																	<tr>
																		<td colspan="2">
																			<img src="<?php echo e(asset($UserId->picture)); ?>"
																				class="img-thumbnail" width="100px" width="100px"  style="box-shadow: 0px 2px 7px 2px gray ;" alt="Ayedun Students' Union"/>
																		</td>
																	</tr>
																	<tr>
																		<th>
																			FULL NAME:
																		</th>
																		<td>
																			<?php echo e($UserId->full_name); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			OFFICE:
																		</th>
																		<td>
																			<?php echo e($UserId->post); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			DESCIPLINE:
																		</th>
																		<td>
																			<?php echo e($UserId->discepline); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			GENDER:
																		</th>
																		<td>
																			<?php echo e($UserId->gender); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			DATE OF BIRTH:
																		</th>
																		<td>
																			<?php echo e($UserId->date_of_birth); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			COMPOUND:
																		</th>
																		<td>
																			<?php echo e($UserId->compound); ?>

																		</td>
																	</tr>

																	<tr>
																		<th>
																			SCHOOL:
																		</th>
																		<td>
																			<?php echo e($UserId->institution); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			YEAR OF TNURE FROM:
																		</th>
																		<td>
																			<?php echo e($UserId->year_of_tenure_from); ?>

																		</td>
																	</tr>
                                                                    <tr>
																		<th>
																			YEAR OF TNURE TO:
																		</th>
																		<td>
																			<?php echo e($UserId->year_of_tenure_to); ?>

																		</td>
																	</tr>

																	<tr>
																		<th>
																			HISTORY/PROJECT EXECUTED:
																		</th>
																		<td>
																			<?php echo e($UserId->history); ?>

																		</td>
																	</tr>
																	<tr>
																		<th>
																			PHONE NUMBER:
																		</th>
																		<td>
																			<?php echo e($UserId->phone); ?>

																		</td>
																	</tr>
																	<tr>
																		<td colspan="2">
																			
																	<button class="btn btn-info" style="float: right; background-color: #4CAF50;
                                                  color: white;
                                                  padding: 14px 20px;
                                                  margin: 8px 0;
                                                  border: none;
                                                  cursor: pointer;
                                                  width: 100%;"> <a style="text-decoration: none; color: #fff; "
																					 href=<?php echo e(url('user/home')); ?>>GO HOME</a></button>
																
																			
																		</td></tr>		
																</table>
																</table>
															</details>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
							</div>
							<div class="col-sm-6">	
				</div>
			</div>
		</div>
	</div>
	<!-- ============================================================== -->
	</div>

	</div>
	<!-- ============================================================== -->
	<!-- End Container fluid  -->
	<!-- ============================================================== -->

	</div>
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
</body>

</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/ViewChapterPresidentProfile.blade.php ENDPATH**/ ?>
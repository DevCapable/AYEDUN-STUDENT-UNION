<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User | Dashboard</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
        .chat_message_area {
            position: relative;
            width: 100%;
            height: auto;
            background-color: #FFF;
            border: 1px solid #CCC;
            border-radius: 3px;
        }

        #group_chat_message {
            width: 100%;
            height: auto;
            min-height: 80px;
            overflow: auto;
            padding: 6px 24px 6px 12px;
        }

        .image_upload {
            position: absolute;
            top: 3px;
            right: 3px;
        }

        .image_upload>form>input {
            display: none;
        }

        .image_upload img {
            width: 24px;
            cursor: pointer;
        }

    </style>
</head>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body style="padding-top: 100px">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
            </div>
            <div class="col-sm-6">
                <form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
                            style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
                            Picture</a></button>
                </form>
                <form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
                    <?php echo csrf_field(); ?>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary">Log Out</button>
                </form><a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-info">Go
                    Back</a><a href="<?php echo e(url('user/onlineUsers')); ?>" class="btn btn-info">Online Users</a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder">inbox</h3>
                        <h3 class="pull-right"></h3>
                    </div>
                    <?php $__currentLoopData = $getMessageForUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <table class="table" style="">

                            <tr>
                                <td>
                                    <?php echo e($item->from_who); ?>


                                </td>

                                <td style="float: inherit;">
                                    <i> <?php echo e($item->message); ?></i>
                                </td>
                                <td style="float: right">
                                    <span style="float: left"
                                        class="badge badge-info pull-right"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?>

                                    </span>
                                </td>
                                <td style="float: right">

                                    <a title="Click to View Delete"
                                        href="<?php echo e(url('user/deleteMyMessage/' . $item->id)); ?>"
                                        class="btn btn-outline-danger btn-sm pull-right">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a title="Click to View Profile"
                                        href="<?php echo e(url('user/startChatting/' . $item->from_who)); ?>"
                                        class="btn btn-outline-primary btn-sm pull-right">
                                        reply
                                    </a>
                                    <a title="Click to View Profile"
                                        href="<?php echo e(url('user/view_user_profile/' . $item->id)); ?>"
                                        class="btn btn-outline-primary btn-sm pull-right">
                                        <i class="fa fa-user"></i>
                                    </a>

                                </td>
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="card-footer">
                        <div class="card card-body bg-transparent">
                            <?php echo e($getMessageForUser->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
            <!-- ============================================================== -->
        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->


    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/inbox.blade.php ENDPATH**/ ?>
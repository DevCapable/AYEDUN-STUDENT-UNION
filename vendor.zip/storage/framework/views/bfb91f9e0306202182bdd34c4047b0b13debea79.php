<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User | Dashboard</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        #postbutton {
            background-color: green;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            font-size: 14;
            font-weight: bold;
        }

        #postbutton:hover {
            background-color: #00ffff;
            color: red;
            font-size: 14;
            font-weight: bold;
        }

        body {
            font-family: Arial;
        }

        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }

        .card:hover {
            box-shadow: 0px 2px 7px 2px gray;
        }

    </style>
</head>

<body style="padding-top: 100px">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <?php if(Session::has('user')): ?>
                    <div class="alert alert-success" style="margin-right:300px">
                        Online
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-6">

                <form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
                            style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
                            Picture</a></button>
                </form>
                
                
            </div>
        </div>
        <div class="row mt-12">
            <div class="col-md-12 offset-col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">WELCOME TO HOME</h4>

                    </div>
                    <div class="card-body">
                        <!--NOTIFICATION STARTS HERE-->
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close"
                                    data-dismiss="alert">×</button><strong><?php echo e(session('success')); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close"
                                    data-dismiss="alert">×</button><strong><?php echo e(session('error')); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><span style="color: red"><?php echo e($error); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <!--NOTIFICATION ENDS HERE-->
                        <div class="row">
                            <div class="col-sm-6">
                                <section class="blog-page">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 col-md-offset-2">
                                                <div class="blog-item">
                                                    <div class="date"> <span style="float: left"
                                                            class="badge badge-info pull-right">You Are Active just
                                                            <?php echo e(Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?>

                                                        </span><br></div>
                                                    <div class="down-content">
                                                        <img src="<?php echo e(asset($user->picture)); ?>" class="img-thumbnail"
                                                            width="75" />
                                                        <div class="row">

                                                            <details>
                                                                <summary style="background-color:red; color:#fff;">
                                                                    ...See <i class="fa fa-eye"></i> You
                                                                    About info </summary>
                                                                <table class="table"
                                                                    style="padding-left: 20px; margin-left: 30px;">

                                                                    <tr>
                                                                        <th>
                                                                            FULL NAME:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->fullname); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            USER NAME:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->username); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            EMAIL:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->email); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            GENDER:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->gender); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            DATE OF BIRTH:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->date_of_birth); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            COMPOUND:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->compound); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>
                                                                            SCHOOL:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->institution); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            PLACE OF RESIDENCE:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->place_of_residence); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>
                                                                            MARITAL STATUS:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->marital_status); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            PHONE NUMBER:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($user->phone); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            <button class="btn btn-info" style="float: right; background-color: #4CAF50;
                                                  color: white;
                                                  padding: 14px 20px;
                                                  margin: 8px 0;
                                                  border: none;
                                                  cursor: pointer;
                                                  width: 100%;"> <a style="text-decoration: none; color: #fff; "
                                                                                    href=<?php echo e(url('user/Edit_profile')); ?>>Edit/Update</a></button>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>

                                                                            <details>
                                                                                <summary>
                                                                                    <center>
                                                                                        <p
                                                                                            style="text-align: center;color: red">
                                                                                            <i class="fa fa-eye"></i>
                                                                                            Password Recovery Details
                                                                                </summary>
                                                                                <hr>
                                                                                </p>
                                                                                </center>
                                                                                <table>

                                                                                    <tr>
                                                                                        <td style="color: red">

                                                                                            Security Question
                                                                                        </td>
                                                                                        <td> <?php echo e($user->security_question); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="color: red">
                                                                                            Answer
                                                                                        </td>
                                                                                        <td> <?php echo e($user->answers); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </details>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </details>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="tab">
                                    <button class="tablinks" onclick="openCity(event, 'comment')"><i id="post"
                                            class="fa fa-comments"></i></button>
                                    <button class="tablinks" onclick="openCity(event, 'picture')"><i id="post"
                                            class="fa fa-image"></i></button>
                                    <button class="tablinks" onclick="openCity(event, 'video')"><i id="post"
                                            class="fa fa-video"></i></button>
                                    <div style="font-size: 12px;"><br><i class="fa fa-arrow-left"></i> What's on your
                                        mind? Click on Tabs</div>
                                </div>
                                <form method="POST" action="<?php echo e(url('user/posting')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div id="comment" class="tabcontent">
                                        <h3>Post Comment Here </h3>
                                        <div class="form-group <?php echo e($errors->has('posting') ? 'has-error' : ''); ?>">
                                            <textarea id="editor" cols="40" rows="4" name="posting"
                                                placeholder="What's on your mind..."></textarea><br>
                                            <?php if($errors->has('posting')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('posting')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <button type="submit" id="postbutton" novallidate>POST</button>
                                        </div>
                                    </div>
                                </form>
                                <form method="POST" action="<?php echo e(url('user/UploadImagePost')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div id="picture" class="tabcontent">
                                        <h3>Post Pictures Here</h3>
                                        <div class="form-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">

                                            <input type="file" name="image"><br>
                                            <?php if($errors->has('image')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('image')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div
                                            class="form-group <?php echo e($errors->has('ImageCaption') ? 'has-error' : ''); ?>">

                                            <textarea id="text" cols="40" rows="4" name="ImageCaption"
                                                placeholder="Image Caption..."></textarea><br>
                                            <?php if($errors->has('ImageCaption')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('ImageCaption')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <button type="submit" id="postbutton" novallidate>POST</button>

                                        </div>
                                    </div>
                                </form>
                                <form method="POST" action="<?php echo e(url('user/UploadVideoPost')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div id="video" class="tabcontent">
                                        <h3>Post Video Here</h3>
                                        <div class="form-group <?php echo e($errors->has('video') ? 'has-error' : ''); ?>">
                                            <input type="file" name="video">
                                            <?php if($errors->has('Video')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('Video')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div
                                            class="form-group <?php echo e($errors->has('VideoCaption') ? 'has-error' : ''); ?>">
                                            <textarea id="text" cols="40" rows="4" name="VideoCaption"
                                                placeholder="Video Caption..."></textarea><br>
                                            <?php if($errors->has('VideoCaption')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('VideoCaption')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <button type="submit" id="postbutton" novallidate>POST</button>

                                        </div>
                                    </div>
                                </form>
                                <!--- end of posting tabs-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <!--SEARCH HERE-->
            <?php echo $__env->make('searchUsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!---SEARXH ENDS HERE--->
            <div class="col-lg-12 col-md-12" style="padding-top: 20px">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder">User's Latest Post
                        </h3>
                        <h3 class="pull-right"><a style="float: right" class="btn btn-primary btn-sm"
                                href="<?php echo e(url('user/onlineUsers')); ?>">Chat Here
                            </a></h3>
                    </div>
                    <div class="card-body" style="">
                        <div class="row el-element-overlay">
                            <?php $__currentLoopData = $All_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-md-3 col-sm-6" style="padding-top: 20px">
                                    <div class="card bg-white card-hover">
                                        <div class="card-header">
                                            <?php if($user->id == $item->userId): ?>
                                                <a title="Click to Delete"  onclick="return confirm('Are you sure you want to delete this <?php echo e($item->username); ?>?')"
                                                    href="<?php echo e(url('user/delete_my_post/' . $item->id)); ?>">
                                                    <button id="delete-btn" value="0329/133"
                                                        class="btn btn-outline-danger btn-sm">
                                                        <i class="fa fa-trash font-weight-bolder"></i>
                                                    </button>
                                                </a>
                                                <a title="Click to Edit"
                                                    href="<?php echo e(url('user/editPost/' . $item->id)); ?>">
                                                    <button id="edit-btn" value="0329/133"
                                                        class="btn btn-outline-info btn-sm">
                                                        <i class="fa fa-edit font-weight-bolder"></i>
                                                    </button>
                                                </a>
                                            <?php endif; ?>
                                            <span class="badge badge-success pull-right">
                                                <?php echo e(strtoupper($item->username)); ?></span>
                                            <span style="float: right" class="badge badge-info pull-right">
                                                <?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?>

                                            </span>
                                        </div>

                                        <div class="card-title">
                                            <p
                                                style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">

                                                <?php if($item->video == '' && $item->image == ''): ?>
                                                    <?php echo $item->posting; ?>

                                                <?php elseif($item->posting =='' && $item->video==''): ?>
                                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-thumbnail"
                                                        width="100%" height="190%" />
                                                    <p
                                                        style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">
                                                        <?php echo $item->ImageCaption; ?>

                                                    </p>
                                                <?php elseif($item->posting =='' && $item->image ==''): ?>
                                                    <video width="100%" height="100%" controls>
                                                        <source src="<?php echo e(asset($item->video)); ?>" type="video/mp4">
                                                    </video>
                                                    <p
                                                        style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">
                                                        <?php echo $item->VideoCaption; ?>

                                                    </p>
                                                <?php endif; ?>
                                            </p>
                                        </div>


                                        <div class="card-footer">
                                            <?php
                                                $isLiked = $item->likes
                                                    ->whereIn('post_id', [$item->id])
                                                    ->whereIn('user_id', [$user->id])
                                                    ->count();
                                            ?>

                                            <?php if($isLiked): ?>
                                                <a title="Click to UnLike" href="<?php echo e(url('user/like/' . $item->id)); ?>"
                                                    class="btn btn-primary btn-sm pull-left">
                                                    <i class="fa fa-thumbs-up"></i>
                                                    <span><?php echo e($item->likes->count()); ?></span>
                                                </a>
                                            <?php else: ?>
                                                <a title="Click to like" href="<?php echo e(url('user/unlike/' . $item->id)); ?>"
                                                    class="btn btn-inverse btn-sm pull-left">
                                                    <i class="fa fa-thumbs-up"></i>
                                                    <span><?php echo e($item->likes->count()); ?></span>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <a title="Click to comment"
                                                href="<?php echo e(url('user/commentPage/' . $item->id)); ?>"
                                                class="btn btn-outline-info btn-sm pull-left">
                                                <i class="fa fa-comments"></i>
                                                <span><?php echo e($whosComment); ?></span>
                                            </a>
                                            <a href="<?php echo e(url('user/view_user_profile/' . $item->userId)); ?>"
                                                class="btn btn-outline-primary btn-sm pull-right">
                                                PROFILE<i class="fa fa-eye"></i>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="card card-body bg-transparent">
                            <?php echo e($All_post->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
    </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->

    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('#editor').val('')
        })

        $(document).on('click', '.button', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            swal({
                    title: "Are you sure!",
                    type: "error",
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Yes!",
                    showCancelButton: true,
                },
                function() {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(url('/destroy')); ?>",
                        data: {
                            id: id
                        },
                        success: function(data) {
                            //
                        }
                    });
                });
        });

    </script>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });

    </script>
    <script>
        function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();

    </script>
     <script>
        const Toast = Swal.mixin({
          toast: true,
          position: '',
          showConfirmButton: false,
          timer: 5000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        Toast.fire({
          icon: 'success',
          title: 'WELCOME!, Your Session is still on, Dont forget to Log out'
        })
      </script>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/home.blade.php ENDPATH**/ ?>
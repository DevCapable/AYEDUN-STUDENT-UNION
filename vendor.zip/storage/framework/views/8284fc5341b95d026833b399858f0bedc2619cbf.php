<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User | Dashboard</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

    </style>
</head>

<body style="padding-top: 100px">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
            </div>
            <div class="col-sm-6">
                <form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
                            style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
                            Picture</a></button>
                </form>
                <form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
                    <?php echo csrf_field(); ?>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary">Log Out</button>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            </div>
            <div class="col-md-12">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close"
                            data-dismiss="alert">×</button><strong><?php echo e(session('success')); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close"
                            data-dismiss="alert">×</button><strong><?php echo e(session('error')); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="card card-default">
                    <div class="card-header">
                        <h3>Student Information Update</h3>
                    </div>
                    <div class="card-body">

                        <form method="POST" novalidate id="update-profile">
                            <input type="hidden" value="/9j/">
                            <div class="row">
                                <div class="col-md-12 form-group" style="margin-bottom: 20px;">
                                    <img src="<?php echo e(asset($user->picture)); ?>" , alt="user Picture" id="image-previewer"
                                        class="pull-right" style="width: 120px;
                                                    height: 120px;
                                                    border: 2px solid #2cabe3;" />
                                </div>
                            </div>
                       

                            <div class="row">


                                <form method="POST" novalidate>
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label for="email">ID Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->id_number); ?>"
                                                data-val="true" id="email" name="" readonly>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('fullname') ? 'has-error' : ''); ?>">
                                            <label for="fullname">Full Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->fullname); ?>"
                                                id="fullname" name="fullname">
                                            <?php if($errors->has('fullname')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('fullname')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label for="email">Email address <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->email); ?>"
                                                data-val="true" id="email" name="" readonly>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="username">User Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($user->username); ?>"
                                                id="username" name="" readonly>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div
                                            class="form-group <?php echo e($errors->has('date_of_birth') ? 'has-error' : ''); ?>">
                                            <label for="date_of_birth">Date of birth <span
                                                    class="text-danger">*</span></label>
                                            <input type="date" class="form-control" value="<?php echo e($user->date_of_birth); ?>"
                                                data-val="true" id="date_of_birth" name="date_of_birth">
                                            <?php if($errors->has('date_of_birth')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('date_of_birth')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('compound') ? 'has-error' : ''); ?>">
                                            <label for="compound">Compound <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->compound); ?>"
                                                data-val="true" id="compound" name="compound" readonly>
                                            <?php if($errors->has('compound')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('compound')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('institution') ? 'has-error' : ''); ?>">
                                            <label for="institution">Institution <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->institution); ?>"
                                                data-val="true" id="institution" name="institution">
                                            <?php if($errors->has('institution')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('institution')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div
                                            class="form-group <?php echo e($errors->has('place_of_residence') ? 'has-error' : ''); ?>">
                                            <label for="place_of_residence">Place of residence <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($user->place_of_residence); ?>" id="place_of_residence"
                                                name="place_of_residence">
                                            <?php if($errors->has('place_of_residence')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('place_of_residence')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div
                                            class="form-group <?php echo e($errors->has('marital_status') ? 'has-error' : ''); ?>">
                                            <label for="marital_status">Marital status <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($user->marital_status); ?>" id="marital_status"
                                                name="marital_status">
                                            <?php if($errors->has('marital_status')): ?>
                                                <span
                                                    class="font-weight-bold"><?php echo e($errors->first('marital_status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div
                                            class="form-group <?php echo e($errors->has('security_question') ? 'has-error' : ''); ?>">
                                            <label for="security_question">Current security_question is :
                                                <span><strong><?php echo e($user->security_question); ?></strong></span></label>
                                            <select type="text" name="security_question" id="security_question"
                                                class="form-control" value="<?php echo e(old('security_question')); ?>">
                                                <option value="<?php echo e($user->security_question); ?>">...Change it?...
                                                </option>
                                                <option value="What is your mother's name">What is your mother's name
                                                </option>
                                                <option value="What was your childhood nickname">What was your childhood
                                                    nickname</option>
                                                <option value="What is your street name">What is your street name
                                                </option>
                                                <option value="What is your favorite food">What is your favorite food
                                                </option>
                                                <option value="What age you got married">What age you got married
                                                </option>

                                                <?php if($errors->has('security_question')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('security_question')); ?></span>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('answers') ? 'has-error' : ''); ?>">
                                            <label for="answers">Answers <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->answers); ?>"
                                                id="answers" name="answers">
                                            <?php if($errors->has('answers')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('answers')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                                            <label for="gender">Gender <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->gender); ?>"
                                                id="gender" name="gender">
                                            <?php if($errors->has('gender')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('gender')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                            <label for="phone">Phone <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value="<?php echo e($user->phone); ?>"
                                                id="phone" name="phone">
                                            <?php if($errors->has('phone')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('phone')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <button type="submit" id="submit-btn" class="btn btn-primary pull-right ml-3"
                                        novallidate>
                                        Update Record
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="card-footer">
                        <h5 class="card-title text-uppercase text-center">
                            <a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-info">Go
                                Back</a>
                        </h5>
                    </div>
                </div>
            </div>
        </div> <!-- /.row -->
    </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/Edit_profile.blade.php ENDPATH**/ ?>
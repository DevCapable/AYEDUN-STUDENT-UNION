<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User | Dashboard</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }


        span {
            float: right;
        }

        .card:hover {
            box-shadow: 0px 2px 7px 2px gray;
        }

        img {
            border-radius: 100px;
        }

    </style>
</head>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body style="padding-top: 100px">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
            </div>
            <div class="col-sm-6">
                <form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
                            style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
                            Picture</a></button>
                </form>
                <form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
                    <?php echo csrf_field(); ?>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary">Log Out</button>
                </form>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder">Comments</h3>
                        <h3 class="pull-right"><a
                                href="javascript:void(0)" onclick="window.history.back();" class="btn btn-info">Go
                                Back</a></h3>
                    </div>
                    
                   
                        <div class="card-header">
                            <p
                                style=" text-align: center; height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">

                                <?php if($checkPost->video == '' && $checkPost->image == ''): ?>
                                    <?php echo $checkPost->posting; ?>

                                <?php elseif($checkPost->posting =='' && $checkPost->video==''): ?>
                                    <img src="<?php echo e(asset($checkPost->image)); ?>" class="img-thumbnail"
                                        width="60%" height="70%" />

                                    <p
                                        style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">
                                        <?php echo $checkPost->ImageCaption; ?>

                                    </p>
                                <?php elseif($checkPost->posting =='' && $checkPost->image ==''): ?>


                                    <video width="100%" height="190%" controls>
                                        <source src="<?php echo e(asset($checkPost->video)); ?>" type="video/mp4">
                                    </video>
                                    <p
                                        style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">
                                        <?php echo $checkPost->VideoCaption; ?>

                                    </p>
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <table class="table" style="">

                            <tr>
                                <td>
                                    <?php echo e($item->username); ?>

                                    
                                </td>

                                <td style=" width: 50% ">
                                   <i style="border-color: grey; border-style: solid; border-radius: 100px; padding: 10px"> <?php echo e($item->comment); ?></i>
                                </td>
                                


                                <td style="float: right ;"  >
                                    <span style="float: left" class="badge badge-info pull-right"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?> </span>
                                   
                                </td>
                                <td style="float: right" colspan="4">
                                    <?php if($verifyUser->id == $item->userId): ?>
                                    <a title="Click to View Delete" href="<?php echo e(url('user/deleteCommentToPost/' . $item->id)); ?>"
                                        class="btn btn-outline-danger btn-sm pull-right">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a title="Click to View Edit" href="<?php echo e(url('user/editCommentToPost/' . $item->id)); ?>"
                                        class="btn btn-outline-info btn-sm pull-right">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a title="Click to View Profile" href="<?php echo e(url('user/view_user_profile/' . $item->id)); ?>"
                                        class="btn btn-outline-primary btn-sm pull-right">
                                        <i class="fa fa-user"></i>
                                    </a>
                                                                          
                                    
                                    <?php else: ?>
                                    <a title="Click to View Profile" href="<?php echo e(url('user/view_user_profile/' . $item->id)); ?>"
                                        class="btn btn-outline-primary btn-sm pull-right">
                                        <i class="fa fa-user"></i>
                                    </a>
                    
                                   <?php endif; ?>
                                </td>
                            </tr>
                            
                            
                            
                            
                        </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <div class="card-footer">
                        <div class="card card-body bg-transparent">
                            <?php echo e($comments->links()); ?>

                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(url('user/commentPage')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <!-- comment here-->
                        <div class="card-body">
                            <i style="display: none">
                            <input  class="form-control" type="text" name="username" value="<?php echo e($verifyUser->username); ?>">
                            <input type="number" name="userId" id="userId" class="form-control"
                            value="<?php echo e($verifyUser->id); ?>"><br>
                            <input type="text" name="postId" id="postId" class="form-control"
                            value="<?php echo e($checkPost->id); ?>"><br>
                            </i>
                            <center> <textarea style="align-self" id="" cols="55" rows="4" name="comment"
                                placeholder="What's on your mind..."></textarea><br>
                            <?php if($errors->has('posting')): ?>
                                <span class="font-weight-bold"><?php echo e($errors->first('posting')); ?></span>
                            <?php endif; ?></center>
                            <button type="submit" class="btn btn-outline-primary btn-lg btn-block"><i class=" fa fa-comments"></i> Comment</button>
                        </div>
                        <div class="card-footer">
                            <div class="card card-body bg-transparent">
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
    </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
   

    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/commentPage.blade.php ENDPATH**/ ?>
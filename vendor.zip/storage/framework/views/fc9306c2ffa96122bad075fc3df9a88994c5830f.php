<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User | Log in</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/dist/css/adminlte.min.css')); ?>">
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        #twitter,
        #facebook,
        #linkedin,
        #google {
            background-color: #205d7a;
            color: #fff;
            width: 40px;
            height: 40px;
            top: 52px;
            border-radius: 40px;
            font-size: 25px;
            text-align: center;
            margin-right: 0px;
            padding-top: 02%;
            transition: all 0.2s eas-in-out;
        }

        #facebook:hover,
        #twitter:hover,
        #linkedin:hover,
        #google:hover {
            opacity: .7;


        }

        #twitter {
            background-color: #00aced;

        }

        #google {
            background-color: #dd4b39;

        }

        #facebook {
            background-color: #3b5998;

        }

        #linkedin {
            background-color: #007bb6;

        }

        #dropdown {
            background-color: #1f2e2e;
            color: #fff;
            border-bottom: 1px dotted #fff;
        }

        #dropdown:hover {
            color: #1affd1;
        }

        /* MY SIDEBAR*/
        #mySidenav a {
            position: fixed;
            left: -80px;
            transition: 0.3s;
            padding: 15px;
            padding-right: 20px;
            padding-left: 2px;
            z-index: 1;
            width: 100px;
            text-decoration: none;
            font-size: 20px;
            color: white;
            border-radius: 0 5px 5px 0;
        }

        #mySidenav a:hover {
            left: 0;
        }

        #about {
            top: 140px;
            background-color: #4CAF50;
        }

        #map {
            top: 200px;
            background-color: #2196F3;
        }

        #projects {
            top: 260px;
            background-color: #ff66d9;
        }

        #developer {
            top: 320px;
            background-color: #f44336;
        }

        #contact {
            top: 380px;
            background-color: #555
        }

        ul {
            display: inline-flex;
            list-style: none;
            color: #fff;
            margin: 0px;

        }


        #twitterb,
        #facebookb,
        #linkedinb,
        #googleb {
            background-color: #205d7a;
            color: #fff;
            width: 40px;
            height: 40px;
            top: 50px;
            border-radius: 40px;
            font-size: 25px;
            text-align: center;
            margin-right: 0px;
            padding-top: 15%;
            transition: all 0.2s eas-in-out;
        }

        #googleb:hover,
        #twitterb:hover,
        #linkedinb:hover,
        #facebookb:hover {
            color: red;
            background-color: #33ff77;
        }
    </style>
</head>

<body class="hold-transition login-page">
    <div class="login-box">

        <!-- /.login-logo -->
        <div class="card">
            <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="email" class="col-md-12 col-form-label text-md-left"><?php echo e(__('E-Mail Address')); ?></label>

                        <div class="col-md-12">
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-12 ">
                            <button type="submit" class="btn btn-primary btn-block">
                                <?php echo e(__('Send Password Reset Link')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.login-box -->
    <br><br>
    <!-- footer starts here-->
    
    <!-- jQuery -->
    <script src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('/dist/js/adminlte.min.js')); ?>"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/reset.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin | Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        summary {
            background-color: greenyellow;
            font-size: 15px;
        }

        summary:hover {
            color: rgb(240, 218, 218);
            background-color: green;
        }
    </style>
</head>

<body style="padding-top: 1px">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="index3.html" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="#" class="nav-link">Contact</a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Navbar Search -->
            <li class="nav-item">
                <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                    <i class="fas fa-search"></i>
                </a>
                <div class="navbar-search-block">
                    <form class="form-inline">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>

            <!-- Messages Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-comments"></i>
                    <span class="badge badge-danger navbar-badge">3</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    Brad Diesel
                                    <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">Call me whenever you can...</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    John Pierce
                                    <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">I got your message bro</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    Nora Silvester
                                    <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">The subject goes here</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-bell"></i>
                    <span class="badge badge-warning navbar-badge">15</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-item dropdown-header">15 Notifications</span>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-envelope mr-2"></i> 4 new messages
                        <span class="float-right text-muted text-sm">3 mins</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-users mr-2"></i> 8 friend requests
                        <span class="float-right text-muted text-sm">12 hours</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-file mr-2"></i> 3 new reports
                        <span class="float-right text-muted text-sm">2 days</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                    <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                    <i class="fas fa-th-large"></i>
                </a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>DataTables</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">DataTables</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger">
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-12">
                        
                        <!-- Form To Add Compound-->
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> <strong>ADD COMPOUND<strong></h4>
                            </div>
                            <div class="card card-body bg-transparent">


                                <form method="POST" novalidate>
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <form method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-md-6">
                                                <input type="file" name="image" class="form-control">
                                            </div>
                                            <div class="col-md-6">
                                                <button type="submit" class="btn btn-success">Upload</button>
                                            </div>
                                        </form>
                                        <div class="col-md-6">

                                            <div
                                                class="form-group <?php echo e($errors->has('Name_of_Compound') ? 'has-error' : ''); ?>">
                                                <label for="Name_of_Compound">Compound Name</label>
                                                <input type="text" name="Name_of_Compound" id="Name_of_Compound"
                                                    class="form-control" value="<?php echo e(old('Name_of_Compound')); ?>">
                                                <?php if($errors->has('Name_of_Compound')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('Name_of_Compound')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('head_of_compound') ? 'has-error' : ''); ?>">
                                                <label for="head_of_compound">Head of Compound</label>
                                                <input type="text" name="head_of_compound" id="head_of_compound"
                                                    class="form-control" value="<?php echo e(old('head_of_compound')); ?>">
                                                <?php if($errors->has('head_of_compound')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('head_of_compound')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('history_of_compound') ? 'has-error' : ''); ?>">
                                                <label for="history_of_compound" class="form-label">History of
                                                    Compound</label>
                                                <input type="text" name="history_of_compound" class="form-control"
                                                    id="history_of_compound" value="<?php echo e(old('history_of_compound')); ?>">
                                                <?php if($errors->has('history_of_compound')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('history_of_compound')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('origin') ? 'has-error' : ''); ?>">
                                                <label for="origin">Origin</label>
                                                <input type="text" name="origin" id="origin" class="form-control"
                                                    value="<?php echo e(old('origin')); ?>">
                                                <?php if($errors->has('origin')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('origin')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('culture_of_compound') ? 'has-error' : ''); ?>">
                                                <label for="culture_of_compound">Culture of Compound</label>
                                                <select type="text" name="culture_of_compound" id="culture_of_compound"
                                                    class="form-control" value="<?php echo e(old('culture_of_compound')); ?>">
                                                    <option value="">...Select...</option>
                                                    <option value="Equngun">Equngun</option>
                                                    <option value="Hepa">Hepa</option>
                                                    <option value="Ifa">Ifa</option>
                                                    <option value="Elewe">Elewe</option>
                                                    <option value="None">None</option>
                                                    <?php if($errors->has('culture_of_compound')): ?>
                                                    <span class="font-weight-bold"><?php echo e($errors->first('culture_of_compound')); ?></span>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                                <label for="phone">Comp. Head Phone</label>
                                                <input type="number" name="phone" id="phone" class="form-control"
                                                    value="<?php echo e(old('phone')); ?>">
                                                <?php if($errors->has('phone')): ?>
                                                <span class="font-weight-bold"><?php echo e($errors->first('phone')); ?></span>
                                                <?php endif; ?>
                                            </div>

                                            <button type="submit" class="btn btn-outline-primary">Create</button>

                                        </div>
                                    </div>
                                </form>

                            </div>
                            <div class="card-footer">
                                <div class="card card-body bg-transparent">
                                    Please enter a valid information
                                </div>
                            </div>

                            <!-- /.row -->



                        </div>
                    </div>
                    <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/admin/Edit_compound.blade.php ENDPATH**/ ?>
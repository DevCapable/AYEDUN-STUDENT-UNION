<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a id="homename" class="navbar-brand" href=<?php echo e(url('user/home')); ?>><img
        style="border-radius: 100px; border-style:double; border-color:#009933" src="<?php echo e(asset('img/ASU_LOGO.png')); ?>"
        height="60" width="60" class="img-responsive" alt="Cinque Terre" class="img-rounded"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
      aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active"><a class="nav-link" href=<?php echo e(url('user/home')); ?> class="active"><i
              class="fa fa-home"></i> Home <span class="sr-only">(current)</span></a>
        </li>
        <!-- Dropdown -->
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop"
            data-toggle="dropdown">
            <i class="fa fa-tasks"></i>&nbsp;ASU Arena
          </a>
          <div class="dropdown-menu">
            <a id="dropdown" class="dropdown-item" href="ASUarena.php"><i
                class="fa fa-universal-access"></i>&nbsp;Exlore</a>

            <a id="dropdown" class="dropdown-item" href=<?php echo e(url('user/ViewAllSportDirector')); ?>><i class="fa fa-home"></i>&nbsp;ASU sport
              <a id="dropdown" class="dropdown-item" href="ASUnational.php"><i class="fa fa-street-view"></i>&nbsp;ASU
                National</a>
              <a id="dropdown" class="dropdown-item" href="ASUchapters.php"><i class="fa fa-street-view"></i>&nbsp;ASU
                Chapters</a>
          </div>
        </li>
        <!-- Dropdown -->
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop"
            data-toggle="dropdown">
            <i class="fa fa-folder"></i>&nbsp;More
          </a>
          <div class="dropdown-menu">
            <a id="dropdown" class="dropdown-item" href="profile.php"><i class="fa fa-user"></i>&nbsp;Profile</a>
            <a id="dropdown" class="dropdown-item" href="viewrelative.php"><i
                class="fa fa-users"></i>&nbsp;Relatives</a>
            <a id="dropdown" class="dropdown-item" href=<?php echo e("/hystory.php"); ?>><i class="fa fa-clone"></i>&nbsp;History of
              Compound</a>
            <a id="dropdown" class="dropdown-item" href=<?php echo e(url('user/all_users')); ?>><i
                class="fa fa-users"></i>&nbsp;Connect With Users</a>
          </div>
        </li>
      </ul>
      <form class="form-inline mt-2 mt-md-0" role="search" action="search.php" method="post">
        <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="q"
          title="Please enter any letter/words Here Probably USERNAME, FIRSTNAME, LASTNAME, INSTITUTION TYPE, COMPOUND">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="submit">Search</button>
      </form>
    </div>
    </div>
    </li>
  </nav>
</header>

<div id="mySidenav" class="sidenav">
  <a href="about_us.php" id="about">About </a>
  <a href="map.php" id="map">Map</a>
  <a href="developer.php" id="developer">Developer</a>
  <a href="#" id="projects">Projects</a>
  <a href="#" id="contact">Contact</a>
</div><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>
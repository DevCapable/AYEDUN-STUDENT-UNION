<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin | Dashboard</title>
    <?php echo $__env->make('admin.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        summary {
            background-color: greenyellow;
            font-size: 15px;
        }

        summary:hover {
            color: rgb(240, 218, 218);
            background-color: green;
        }

    </style>
</head>

<body style="padding-top: 1px">
    <!-- sidebar -->
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="index3.html" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="#" class="nav-link">Contact</a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Navbar Search -->
            <li class="nav-item">
                <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                    <i class="fas fa-search"></i>
                </a>
                <div class="navbar-search-block">
                    <form class="form-inline">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>

            <!-- Messages Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-comments"></i>
                    <span class="badge badge-danger navbar-badge">3</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    Brad Diesel
                                    <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">Call me whenever you can...</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    John Pierce
                                    <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">I got your message bro</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <!-- Message Start -->
                        <div class="media">
                            <img src="dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    Nora Silvester
                                    <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                                </h3>
                                <p class="text-sm">The subject goes here</p>
                                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-bell"></i>
                    <span class="badge badge-warning navbar-badge">15</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-item dropdown-header">15 Notifications</span>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-envelope mr-2"></i> 4 new messages
                        <span class="float-right text-muted text-sm">3 mins</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-users mr-2"></i> 8 friend requests
                        <span class="float-right text-muted text-sm">12 hours</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="fas fa-file mr-2"></i> 3 new reports
                        <span class="float-right text-muted text-sm">2 days</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                    <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                    <i class="fas fa-th-large"></i>
                </a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>SPORT DIRECTORS</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">DataTables</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Table below shows all the Available Sport Directors</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <tr>
                                        <td colspan="12" id="header">
                                            <h1>All Sport Directors<h1>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th width="340px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Fullname'));?></th>
                                        <th width="340px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Compound'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Gender'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Descipline'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Institution'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Date Of Birth'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Tenure Year From'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Tenure Year To'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Sport'));?></th>
                                        <th width="135px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('History'));?></th>
                                        <th width="200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('DP'));?></th>
                                        <th width="100px">ACTION</th>
                                    </tr>
                                    <?php $__currentLoopData = $sportDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sportDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="80px"><?php echo e($sportDetail->full_name); ?></td>
                                            <td width="135px"><?php echo e($sportDetail->compound); ?></td>
                                            <td width="80px"><?php echo e($sportDetail->gender); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->discepline); ?></td>
                                            <td width="80px"> <?php echo e($sportDetail->institution); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->date_of_birth); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->year_of_tenure_from); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->year_of_tenure_to); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->sport); ?></td>
                                            <td width="100px"><?php echo e($sportDetail->history); ?></td>
                                            <td width="700px"><img src="<?php echo e(asset($sportDetail->picture)); ?>" class="img-thumbnail"
                                                width="500px" width="500px" style="box-shadow: 0px 2px 7px 2px gray ;"
                                                alt="Ayedun Students' Union" style="border-radius: 100px"/></td>
                                            <td width="340px">


                                                <a onclick="return confirm('Are you sure you want to delete <?php echo e($sportDetail->full_name); ?>?')"
                                                    href="<?php echo e(url('administrator/Delete_Sports', $sportDetail->id)); ?>"
                                                    title="Delete sport Director">
                                                    <i class="fas fa-trash text-danger  fa-lg"></i></a>

                                                <a title="Click to Like"
                                                    href="<?php echo e(url('administrator/Edit_Sports/' . $sportDetail->id)); ?>">
                                                    <button id="edit-btn" value="0329/133"
                                                        class="btn btn-outline-info btn-sm">
                                                        <i class="fa fa-edit font-weight-bolder"></i>
                                                    </button></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>


                            <div class="card-footer">
                                <div class="card card-body bg-transparent">
                                    <?php echo e($sportDetails->links()); ?>

                                </div>
                            </div>
                        </div>
                        <!-- /.col -->

                        <!-- Form To Add Compound-->
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> <strong>ADD NEW ELECTED SPORT DIRECTOR<strong></h4>
                            </div>
                            <div class="card card-body bg-transparent">

                                <form method="POST" novalidate>
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('full_name') ? 'has-error' : ''); ?>">
                                                <label for="full_name">Full Name</label>
                                                <input type="text" name="full_name" id="full_name" class="form-control"
                                                    value="<?php echo e(old('full_name')); ?>"
                                                    placeholder="Enter your full Name">
                                                <?php if($errors->has('full_name')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('full_name')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('compound') ? 'has-error' : ''); ?>">
                                                <label for="compound">Compound</label>
                                                <select type="text" name="compound" id="compound" class="form-control"
                                                    value="<?php echo e(old('compound')); ?>">
                                                    <option value="">...Select...</option>
                                                    <?php $__currentLoopData = $getCompound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value=" <?php echo e($compound->Name_of_Compound); ?>">
                                                            <?php echo e($compound->Name_of_Compound); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($errors->has('compound')): ?>
                                                        <span
                                                            class="font-weight-bold"><?php echo e($errors->first('compound')); ?></span>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                                                <label for="gender">Gender</label>
                                                <select type="text" name="gender" id="gender" class="form-control"
                                                    value="<?php echo e(old('gender')); ?>">
                                                    <option value="">...Select...</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>

                                                    <?php if($errors->has('gender')): ?>
                                                        <span
                                                            class="font-weight-bold"><?php echo e($errors->first('gender')); ?></span>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('discepline') ? 'has-error' : ''); ?>">
                                                <label for="discepline" class="form-label">Descipline</label>
                                                <input type="text" name="discepline" class="form-control"
                                                    id="discepline" value="<?php echo e(old('discepline')); ?>"
                                                    placeholder="Enter your descipline">
                                                <?php if($errors->has('discepline')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('discepline')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('institution') ? 'has-error' : ''); ?>">
                                                <label for="institution">Institution</label>
                                                <select type="text" name="institution" id="institution"
                                                    class="form-control" value="<?php echo e(old('institution')); ?>">
                                                    <option value="">...Select...</option>
                                                    <?php $__currentLoopData = $listOfSchools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listOfSchool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value=" <?php echo e($listOfSchool->ListSchools); ?>">
                                                            <?php echo e($listOfSchool->ListSchools); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($errors->has('institution')): ?>
                                                        <span
                                                            class="font-weight-bold"><?php echo e($errors->first('institution')); ?></span>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('date_of_birth') ? 'has-error' : ''); ?>">
                                                <label for="date_of_birth">Date_of_birth</label>
                                                <input type="date" name="date_of_birth" id="date_of_birth"
                                                    class="form-control" value="<?php echo e(old('date_of_birth')); ?>">
                                                <?php if($errors->has('date_of_birth')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('date_of_birth')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('year_of_tenure_from') ? 'has-error' : ''); ?>">
                                                <label for="year_of_tenure_from">Year_of_tenure_from</label>
                                                <input type="date" name="year_of_tenure_from" id="year_of_tenure_from"
                                                    class="form-control" value="<?php echo e(old('year_of_tenure_from')); ?>">
                                                <?php if($errors->has('year_of_tenure_from')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('year_of_tenure_from')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="form-group <?php echo e($errors->has('year_of_tenure_to') ? 'has-error' : ''); ?>">
                                                <label for="year_of_tenure_to">Year_of_tenure_to</label>
                                                <input type="date" name="year_of_tenure_to" id="year_of_tenure_to"
                                                    class="form-control" value="<?php echo e(old('year_of_tenure_to')); ?>">
                                                <?php if($errors->has('year_of_tenure_to')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('year_of_tenure_to')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('sport') ? 'has-error' : ''); ?>">
                                                <label for="sport">Sport</label>
                                                <select type="text" name="sport" id="sport" class="form-control"
                                                    value="<?php echo e(old('sport')); ?>">
                                                    <option value="">...Select...</option>
                                                    <option value="Hockey">Hockey</option>
                                                    <option value="Ludo">Ludo</option>
                                                    <option value="Draft">Draft</option>
                                                    <option value="Volley Ball">Volleyy Ball</option>
                                                    <option value="Table Tennies">Table Tennies</option>
                                                    <option value="Long Tennies">Long Tennies</option>
                                                    <option value="Swimming">Swimming</option>
                                                    <option value="Town Race">Town Race</option>
                                                    <option value="None">None</option>
                                                    <?php if($errors->has('sport')): ?>
                                                        <span
                                                            class="font-weight-bold"><?php echo e($errors->first('sport')); ?></span>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                                <label for="phone">Phone</label>
                                                <input type="number" name="phone" id="phone" class="form-control"
                                                    value="<?php echo e(old('phone')); ?>">
                                                <?php if($errors->has('phone')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('phone')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group <?php echo e($errors->has('history') ? 'has-error' : ''); ?>">
                                                <label for="phone">History/Project</label>
                                                <div>
                                                    <textarea id="text" cols="30" rows="4" name="history"
                                                        placeholder="Short history..."></textarea>
                                                </div>
                                                <?php if($errors->has('history')): ?>
                                                    <span
                                                        class="font-weight-bold"><?php echo e($errors->first('history')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <button type="submit"
                                            class="btn btn-outline-primary btn-lg btn-block">Create</button>
                                        <a href="javascript:void(0)" onclick="window.history.back();"
                                            class="btn btn-outline-info btn-lg btn-block">Go Back</a>
                                    </div>
                                </form>

                            </div>
                            <div class="card-footer">
                                <div class="card card-body bg-transparent">
                                    Please enter a valid information
                                </div>
                            </div>

                            <!-- /.row -->



                        </div>
                    </div>
                    <!-- /.container-fluid -->

        </section>
        <!-- /.content -->
        <!-- /.content-wrapper -->
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            Toast.fire({
                icon: 'success',
                title: 'Administrator! Here You Can Manage Sport Director'
            })

        </script>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/admin/Manage_Sports.blade.php ENDPATH**/ ?>
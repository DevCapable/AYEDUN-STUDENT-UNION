<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
            color: green;
        }

        .valid:before {
            position: relative;
            left: -20px;
            content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
            color: red;
        }

        .invalid:before {
            position: relative;
            left: -20px;
            content: "✖";
        }
    </style>
</head>

<body style="padding-top: 70px">
    <div class="container">
        <div class="row mt-12">
            <div class="col-md-12 offset-col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">WELCOME TO HOME</h4>
                    </div>
                </div>
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger">
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <?php endif; ?>
                <div class="card-body">
                    <form method="POST" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group <?php echo e($errors->has('fullname') ? 'has-error' : ''); ?>">
                                    <label for="fullname">Fullname</label>
                                    <input type="text" name="fullname" id="fullname" class="form-control"
                                        value="<?php echo e(old('fullname')); ?>">
                                    <?php if($errors->has('fullname')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('fullname')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                    <label for="email" class="form-label">Email address</label>
                                    <input type="email" name="email" class="form-control" id="email"
                                        value="<?php echo e(old('email')); ?>">
                                    <?php if($errors->has('email')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
                                    <label for="username">Username</label>
                                    <input type="text" name="username" id="username" class="form-control"
                                        value="<?php echo e(old('username')); ?>">
                                    <?php if($errors->has('username')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('username')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <!-- ADDITIONAL FILEDS STARTS HERE-->

                                <div class="form-group <?php echo e($errors->has('date_of_birth') ? 'has-error' : ''); ?>">
                                    <label for="date_of_birth">Date_of_birth</label>
                                    <input type="date" name="date_of_birth" id="date_of_birth" class="form-control"
                                        value="<?php echo e(old('date_of_birth')); ?>">
                                    <?php if($errors->has('date_of_birth')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('date_of_birth')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('compound') ? 'has-error' : ''); ?>">
                                    <label for="compound">Compound</label>
                                    <input type="text" name="compound" id="compound" class="form-control"
                                        value="<?php echo e(old('compound')); ?>">
                                    <?php if($errors->has('compound')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('compound')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('institution') ? 'has-error' : ''); ?>">
                                    <label for="institution">Institution</label>
                                    <input type="text" name="institution" id="institution" class="form-control"
                                        value="<?php echo e(old('institution')); ?>">
                                    <?php if($errors->has('institution')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('institution')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('place_of_residence') ? 'has-error' : ''); ?>">
                                    <label for="place_of_residence">Place_of_residence</label>
                                    <input type="text" name="place_of_residence" id="place_of_residence"
                                        class="form-control" value="<?php echo e(old('place_of_residence')); ?>">
                                    <?php if($errors->has('place_of_residence')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('place_of_residence')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('marital_status') ? 'has-error' : ''); ?>">
                                    <label for="marital_status">Marital_status</label>
                                    <input type="text" name="marital_status" id="marital_status" class="form-control"
                                        value="<?php echo e(old('marital_status')); ?>">
                                    <?php if($errors->has('marital_status')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('marital_status')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">

                                <div class="form-group <?php echo e($errors->has('security_question') ? 'has-error' : ''); ?>">
                                    <label for="security_question">security_question</label>
                                    <select type="text" name="security_question" id="security_question"
                                        class="form-control" value="<?php echo e(old('security_question')); ?>">
                                        <option value="">...Select...</option>
                                        <option value="What is your mother's name">What is your mother's name</option>
                                        <option value="What was your childhood nickname">What was your childhood
                                            nickname</option>
                                        <option value="What is your street name">What is your street name</option>
                                        <option value="What is your favorite food">What is your favorite food</option>
                                        <option value="What age you got married">What age you got married</option>

                                        <?php if($errors->has('security_question')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('security_question')); ?></span>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group <?php echo e($errors->has('answers') ? 'has-error' : ''); ?>">
                                    <label for="answers">answers</label>
                                    <input type="text" name="answers" id="answers" class="form-control"
                                        value="<?php echo e(old('answers')); ?>">
                                    <?php if($errors->has('answers')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('answers')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                    <label for="text">Phone</label>
                                    <input type="number" name="phone" id="phone" class="form-control"
                                        value="<?php echo e(old('phone')); ?>">
                                    <?php if($errors->has('phone')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('phone')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <!-- ADDITIONAL FILEDS ENDS HERE -->
                                <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                                    <label for="gender">Gender</label>
                                    <select type="text" name="gender" id="gender" class="form-control"
                                        value="<?php echo e(old('gender')); ?>">
                                        <option value="">...Select...</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>

                                        <?php if($errors->has('gender')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('gender')); ?></span>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div id="message1" style="background-color: rgba(236, 228, 228, 0.479); font-size:10px">
                                    <h6 style="color: red">Password must contain the following:</h6>
                                    <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                    <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                    <p id="number" class="invalid">A <b>number</b></p>
                                    <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                                </div>
                                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                    <label class="control-label" for="password"><i
                                            class="fa fa-lock"></i>Password:</label>
                                    <div>
                                        <input type="password" class="form-control" id="myInput1" name="password"
                                            placeholder="Enter Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                            title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                                        <input type="checkbox" onclick="myFunction()"> Show Password
                                        <?php if($errors->has('password')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button style=" float: right;" type="submit" class="btn btn-primary"><a
                                        style="text-decoration: none; color:white;"
                                        href="<?php echo e(('/login')); ?>">Login</a></button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

<!--  // Second password1 fild-->
<script>
    var password1 = document.getElementById("myInput1");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");



    // When the user clicks on the password field, show the message box
    password1.onfocus = function () {
        document.getElementById("message1").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    password1.onblur = function () {
        document.getElementById("message1").style.display = "none";
    }

    // When the user starts to type something inside the password field
    password1.onkeyup = function () {
        // Validate lowercase letters
        var lowerCaseLetters = /[a-z]/g;
        if (password1.value.match(lowerCaseLetters)) {
            letter.classList.remove("invalid");
            letter.classList.add("valid");
        } else {
            letter.classList.remove("valid");
            letter.classList.add("invalid");
        }

        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if (password1.value.match(upperCaseLetters)) {
            capital.classList.remove("invalid");
            capital.classList.add("valid");
        } else {
            capital.classList.remove("valid");
            capital.classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if (password1.value.match(numbers)) {
            number.classList.remove("invalid");
            number.classList.add("valid");
        } else {
            number.classList.remove("valid");
            number.classList.add("invalid");
        }

        // Validate length
        if (password1.value.length >= 8) {
            length.classList.remove("invalid");
            length.classList.add("valid");
        } else {
            length.classList.remove("valid");
            length.classList.add("invalid");
        }
    }
</script>
<script>
    function myFunction() {
        var x = document.getElementById("myInput1");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>

</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/Registration.blade.php ENDPATH**/ ?>
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a id="homename" class="navbar-brand" href=<?php echo e(url('user/home')); ?>><img
        style="border-radius: 100px; border-style:double; border-color:#009933" src="<?php echo e(asset('img/ASU_LOGO.png')); ?>"
        height="60" width="60" class="img-responsive" alt="Cinque Terre" class="img-rounded"></a>
        <?php if($unreadMessage>0): ?>
        <a  class="btn btn-outline-info" class="nav-link" href=<?php echo e(url('user/inbox')); ?> class="active"><i
          class="fa fa-envelope"></i><span style="font-size: 20px;color: red">
            <i>  <?php echo e($unreadMessage); ?></i></a>
          <?php endif; ?>
          
    
    &nbsp;
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
      aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    

    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active"><a class="nav-link" href=<?php echo e(url('user/home')); ?> class="active"><i
              class="fa fa-home"></i> Home <span class="sr-only">(current)</span></a>
        </li>
        <!-- Dropdown -->
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop"
            data-toggle="dropdown">
            <i class="fa fa-tasks"></i>&nbsp;ASU Arena
          </a>
          <div class="dropdown-menu">
            

            <a id="dropdown" class="dropdown-item" href="<?php echo e(url('user/ViewAllSportDirector')); ?>"><i class="fa fa-home"></i>&nbsp;ASU sport</a>
              <a id="dropdown" class="dropdown-item" href="<?php echo e(url('user/ViewAllNationalPresident')); ?>"><i class="fa fa-street-view"></i>&nbsp;ASU
                National</a>
                <a id="dropdown" class="dropdown-item" href="<?php echo e(url('/user/ViewAllChapterPresident')); ?>"><i class="fa fa-street-view"></i>&nbsp;ASU
                  Chapters</a>
                  <a id="dropdown" class="dropdown-item" href="<?php echo e(url('user/ViewAllNationalExecutive')); ?>"><i class="fa fa-user"></i>&nbsp;National Executives</a>
                  <a id="dropdown" class="dropdown-item" href="<?php echo e(url('user/ViewAllMissAsu')); ?>"><i class="fa fa-user"></i>&nbsp;MISS ASU</a>
              
                </div>
        </li>
        <!-- Dropdown -->
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop"
            data-toggle="dropdown">
            <i class="fa fa-folder"></i>&nbsp;More
          </a>
          <div class="dropdown-menu">
            <a id="dropdown" class="dropdown-item" href="<?php echo e(url('/user/ViewAllRelative')); ?>"><i
                class="fa fa-users"></i>&nbsp;Relatives</a>
                <a id="dropdown" class="dropdown-item" href="<?php echo e(url('/historyOfAyedun')); ?>"><i class="fa fa-clone"></i>&nbsp;History Of
                  Ayedun</a>
            <a id="dropdown" class="dropdown-item" href="<?php echo e(url('/user/ViewAllCompound')); ?>"><i class="fa fa-clone"></i>&nbsp;All Compound</a>
            <a id="dropdown" class="dropdown-item" href="<?php echo e(url('user/all_users')); ?>"><i
                class="fa fa-users"></i>&nbsp;Connect With Users</a>
          </div>

        </li>
        <a  class="btn btn-outline-info" class="nav-link" href="<?php echo e(url('user/inbox')); ?>" class="active"><i
                    class="fa fa-envelope"></i><span style="font-size: 20px;color: red">
                    <?php if($unreadMessage>1): ?>
                      <i> <?php echo e($unreadMessage .'New Messages'); ?></i>
                    <?php else: ?>
                    <?php echo e($unreadMessage); ?>

                        
                    <?php endif; ?>
                     </span> Message<span class="sr-only">(current)</span></a>
              
              &nbsp;
        <form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
          <?php echo csrf_field(); ?>
          <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"><i class="fas fa-sign-out-alt"></i>Sign Out </button>
      </form>
      </ul>
      <form method="Post"  action="<?php echo e(url('user/searchUsers')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="question"
          title="Please enter any letter/words Here Probably USERNAME, FIRSTNAME, LASTNAME, INSTITUTION TYPE, COMPOUND">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="submit">Search</button>
      </form>
    </div>
    </div>
    </li>
  </nav>
</header>

<div id="mySidenav" class="sidenav">

  <a href="<?php echo e(url('user/map')); ?>" id="map">Map</a>
  <a href="<?php echo e(url('user/developer')); ?>" id="developer">Developer</a>


</div>

<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/layouts/header.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>AYEDUN STUDENT UNION</title>
    <!--    -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400">
    <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap-theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/fontAwesome.css')); ?>">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick-theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/tooplate-style.css')); ?>">
    <script src="<?php echo e(asset('slider/js/jquery.js')); ?>"></script>

    <!-- tooplate style -->

    <script>
        var renderPage = true;

        if (navigator.userAgent.indexOf('MSIE') !== -1
            || navigator.appVersion.indexOf('Trident/') > 0) {
            /* Microsoft Internet Explorer detected in. */
            alert("Please view this in a modern browser such as Chrome or Microsoft Edge.");
            renderPage = false;
        }
    </script>
    <style>
        h4 {
            font-family: Bodoni Bd BT;

        }

        #imagge {
            border-radius: 20px;
            border-style: double;
            border-color: #1affff;

        }

        hr {
            size: 40px;
            border-color: #1a4ccf;
            border-style: solid;
        }

        h3 {
            text-align: center;
            background-color: #66ff66;
            padding: 10px;
        }

        #dropdown {
            background-color: #1f2e2e;
            color: #fff;
            border-radius: 20px;
            margin: 5px;
            padding-left: 10%;
            border-bottom: 1px dotted #fff;
        }

        #dropdown:hover {
            color: rgb(243, 237, 237);
            background-color: #f30c65;
        }

        a {
            text-decoration: none;
    </style>
</head>

<body>
    <!-- Loader -->
    <div id="loader-wrapper">
        <div id="loader"></div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>
    <div class="container">
        <section class="tm-section-head" id="top">
            <header id="header" class="text-center tm-text-gray">
                <p><a id="homename" class="navbar-brand" href="index.php"><img style="border-color:#009933"
                            src="img/ASU_LOGO.png" height="80" width="90" class="img-responsive" alt="Cinque Terre"
                            class="img-rounded"></a></p>
                <p style="font-size: 30px; color: #009933; font-family: Exotc350 Bd BT">AYEDUN STUDENTS' UNION
                <p style="font-size: 15px;"> <strong>MOTTO:</strong> <i style=" color: red">Education, Unity and
                        Progress!</i></p>
                </p>
            </header>
            <nav class="navbar narbar-light">
                <a class="navbar-brand tm-text-gray" href="#">
                    Menu
                </a>
                <button type="button" id="nav-toggle" class="navbar-toggler collapsed" data-toggle="collapse"
                    data-target="#mainNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="fa fa-navicon tm-fa-toggler-icon"></i>
                    </span>
                </button>
                <div id="mainNav" class="collapse navbar-collapse tm-bg-white">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a id="dropdown" class="nav-link tm-text-gray" href="#top">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li id="dropdown" class="nav-item">
                            <a style="text-decoration: none; color:#fff " href="#tm-section-2">EXECUTIVES</a>
                        </li>
                        <li id="dropdown" class="nav-item">
                            <a style="text-decoration: none; color:#fff" href="#tm-section-6">CONTACT</a>
                        </li>
                        <li id="dropdown" class="nav-item">
                            <a style="text-decoration: none; color:#fff" href="<?php echo e(('/register')); ?>">STUDENT'S REG.</a>
                        </li>
                        <li id="dropdown" class="nav-item">
                            <a style="text-decoration: none; color:#fff" href="<?php echo e(('/login')); ?>">STUDENTS' LOGIN.</a>
                        </li>
                        <li id="dropdown" class="nav-item">
                            <a style="text-decoration: none; color:#fff" href="<?php echo e(('/administrator')); ?>">ADMIN.</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="navbar navbar-default navbar-fixed-top">
                <a href="/index.html" class="navbar-brand"></a>
                <botton class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mydropdown">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </botton>

            </div>

            <div class="collapse navbar-collapse" id="mydropdown">

                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="#">info</a>
                    </li>

                    <li>
                        <a href="#">contact</a>
                    </li>
                </ul>
            </div>
        </section>

        <section class="row" id="tm-section-1">
            <div class="col-lg-12 tm-slider-col">
                <div class="tm-img-slider">
                    <div class="tm-img-slider-item" href="img/gallery-img-01.jpg">
                        <p class="tm-slider-caption"> 1 .“Education is the most powerful weapon which you can use to
                            change the world” – Nelson Mandela.</p>
                        <img src="img/gallery-img-01.jpg" alt="Image" class="tm-slider-img">
                    </div>
                    <div class="tm-img-slider-item" href="img/gallery-img-02.jpg">
                        <p class="tm-slider-caption"> 2. “The cure for boredom is curiosity. There is no cure for
                            curiosity” – Dorothy Parker.</p>
                        <img src="img/gallery-img-02.jpg" alt="Image" class="tm-slider-img">
                    </div>
                    <div class="tm-img-slider-item" href="img/gallery-img-03.jpg">
                        <p class="tm-slider-caption"> 3. “The beautiful thing about learning is that no one can take it
                            away from you” – B. B. King.</p>
                        <img src="img/gallery-img-03.jpg" alt="Image" class="tm-slider-img">
                    </div>
                    <div class="tm-img-slider-item" href="img/gallery-img-04.jpg">
                        <p class="tm-slider-caption"> 4. “When you educate one person you can change a life, when you
                            educate many you can change the world”- Shai Reshef.</p>
                        <img src="img/beloved.jpeg" alt="Image" class="tm-slider-img">
                    </div>
                </div>
            </div>
        </section>
        <div class="row">
        <section class="tm-section-2 tm-section-mb" id="tm-section-2">
            <p
                style="color: green; text-align: center; font-family: Copperplate Gothic Bold; background-color: #ff9900;">
                <strong>NATIONAL EXECUTIVES</strong> </p>
                <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder">Student's List</h3>
                        <h3 class="pull-right"><a class="btn btn-primary btn-sm" href="#">Chat Room</a> <a
                                href="javascript:void(0)" onclick="window.history.back();" class="btn btn-info">Go
                                Back</a></h3>
                    </div>
                    <div class="card-body" style="">
                        <div class="row el-element-overlay">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><br />
                            <div class="col-lg-3 col-md-3 col-sm-6" style="padding-top: 20px">
                                <div class="card bg-white card-hover" >
                                    <div class="card-header">
                                        <span style="float: left" class="badge badge-info pull-right">Active since <?php echo e(Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?> </span>
                                        <span class="badge badge-success pull-right"><?php echo e($user->gender); ?></span>
                                    </div>
                                    <div class="card-body" style="height: 100%; width: 100%">
                                        <div class="card-title text-center">
                                            <img src="<?php echo e(asset($user->picture)); ?>" class="img_thumbnails" width="200px"
                                                height="200px" class="img-thumbnail" alt="Ayedun Students' Union"/><br />
                                            <?php echo e(strtoupper($user->fullname)); ?>

                                        </div>
                                        <br />
                                    </div>
                                    <div class="card-footer">
                                        <a title="Click to comment" href="<?php echo e(url('user/like/'.$user->id)); ?>"
                                            class="btn btn-outline-info btn-sm pull-left">
                                            <i class="fa fa-comments"></i>
                                        </a>
                                        <a href="<?php echo e(url('user/view_user_profile/'.$user->id)); ?>"
                                            class="btn btn-outline-primary btn-sm pull-right">
                                            <i class="fa fa-eye"></i> PROFILE
                                        </a>
                                        <span class="badge badge-success pull-right"><?php echo e($user->compound); ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="card card-body bg-transparent">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>




            <div class="row">

                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="#"><img id="imagge" style="border-color:#009933"
                                    src="img/Gensec.jpeg" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>General Secretary</h4>
                    <p> Comr. Omotosho Justina
                    </p>


                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="#"><img id="imagge" style="border-color:#009933"
                                    src="img/President.jpeg" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>President</h4>
                    <p> Comr. Kehinde Babalola </p>


                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="#"><img id="imagge" style="border-color:#009933"
                                    src="img/FinSEC.jpeg" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>Financial Secretary</h4>
                    <p> Comr. Kolawole Joachim Segun
                    </p>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="#"><img id="imagge" style="border-color:#009933"
                                    src="img/SocialDirector.jpg" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>Social Director</h4>
                    <p> Comr. Bankole Abidemi Micheal
                    </p>

                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="#"><img id="imagge" style="border-color:#009933"
                                    src="img/Comr.abiola.jpg" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>Welfare Director</h4>
                    <p> Comr. Babalola Abiola
                    </p>

                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-md-5 mb-5 pr-md-5" style="text-align: center;">
                    <header class="text-center">
                        <p><a class="navbar-brand" href="index.php"><img id="imagge" style="border-color:#009933"
                                    src="img/ASU_LOGO.png" height="150" width="150" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded"></a></p>
                    </header>
                    <h4>Sport Directior</h4>
                    <p> Comr. Dada Ahmed Abdulazeez
                    </p>

                </div>
                <br><br>
                <div class="col-xl-8 col-lg-8 col-md-12"
                    style="text-align: justify; background-color: rgb(206, 228, 219);padding-top: 20px;">
                    <h3 style="">AYEDUN STUDENTS' UNION</h3>
                    <p style="text-align: justify; margin: 5PX;"> Ayedun Students’ Union was greatly well founded by
                        Great People Mr. Feyi Olaniyan Chairman protem officials 1980-1981 follow by
                        Mr Timothy Oyeniyi from 1981-1982 and 1984-1986 followed by Mr Aransiola Mathew
                        from 1983-1984 followed by Mr Adekeye Ralph Fola from 1988 -1990 followed by
                        Mr Omotosho Tony Idowu from 1990-1992 followed by Mr Kayode Ola Peter from 1993-1995
                        followed by Mr Omotosho Jacob Tunde from 1996-1998 followed by Mr Abegunde Clement from
                        1999-2000 followed by Mr Afolayan S Rotimi from 2001 -2002 followed by Mr Afolayan S Adedayo
                        from 2003-2004 followed by Mr Obaoye Gbenga David from 2005-2006 followed by Mr Afolayan
                        Akinloye Tonies from 2007-2008 followed by Mr Awoseyin Stephen Olalekan from 2009-2010 followed
                        by Mr Ogunyemi Ralpheal Olawale from 2011 -2012 followed by Mr. Adeyemi Stephen Kola. From 2013-
                        2014 followed by Mr. Jimoh Segun Anthony from 2015- 2016 followed Comr. Emannuel Dare from
                        2017-2020 followed by Comr. Babalola Kehinde from 2020 till date, ASU clocked 40Years December
                        30th 2020 and still counting...
                    <p>GREAT ASU!!!</p>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-12" style="background-color: #000000; color: #ffffff">
                    <hr>
                    <h3>OUR CORE VALUES</h3>
                    <hr>
                    <i>
                        <p><i class="fa fa-check-circle"></i>Education, Unity and Progress</p>

                        <p><i class="fa fa-bullhorn"></i> GREAT ASU!!!</p>
                    </i>
                    <br>
                    <hr>
                    <h3>VISION</h3>
                    <hr>
                    <i>
                        <p><i class="fa fa-hand-point-right"></i> For oneness and unity of the Ayedun
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Indigenous</p>
                        <p><i class="fa fa-hand-point-right"></i>Enhancement of Educational System in both
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home and diaspora
                    </i></p>
                </div>
            </div>
        </section>

        <section class="tm-section-3 tm-section-mb" id="tm-section-3">
            <div class="row">
                <div class="col-md-6 tm-mb-sm-4 tm-2col-l">
                    <div class="image" style="text-align: center;">
                        <p><a id="homename" class="navbar-brand" href="index.php"><img style="border-radius: 20px"
                                    src="img/patron.jpeg" height="250px" width="250px" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded" class="img-fluid" /></a></p>
                    </div>
                    <div class="tm-box-3">
                        <hr>
                        <h2>Patron</h2>
                        <hr>
                        <h5><strong> Egnr. Babalola</strong></h5>
                        <div class="text-center">
                            <a href="#"><i style="font-size: 20px;" class="fa fa-facebook"></i></a> <a href="#"><i
                                    style="font-size: 20px;" class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 tm-2col-r">
                    <div class="image" style="text-align: center;">
                        <p><a id="homename" class="navbar-brand" href="index.php"><img style="border-radius: 20px"
                                    src="img/Obajisun.jpeg" height="250px" width="250px" class="img-responsive"
                                    alt="Cinque Terre" class="img-rounded" class="img-fluid" /></a></p>
                    </div>
                    <div class="tm-box-3">
                        <header>
                            <hr>
                            <h2>Royalness</h2>
                            <hr>
                            <h5><strong> His Royal Majesty Oba Rotimi Orimadegun 1 Arojojoye 2 Obajisun Of Ayedun
                                    City</strong></h5>
                        </header>

                        <div class="text-center">
                            <a href="#"><i style="font-size: 20px;" class="fa fa-facebook"></i></a> <a href="#"><i
                                    style="font-size: 20px;" class="fa fa-instagram"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="tm-section-4 tm-section-mb" id="tm-section-4">
            <div class="row">

            </div>
        </section>

        <section class="tm-section-5" id="tm-section-5">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="image fit">
                        <img src="img/Ayedun_statue.png" class="img-fluid">
                    </div>
                </div>

                <div class="col-lg-8 col-md-12 col-sm-12 pl-lg-0">
                    <div class="media tm-media">
                        <img src="img/Kppresident.jpg" class="img-responsive tm-media-img">
                        <div class="media-body tm-box-5">
                            <h5>Chapter President (Kwarapoly)</h5>
                            <p class="mb-0">Comr. Bankole Abidemi Micheal.</p>
                        </div>
                    </div>
                    <div class="media tm-media">
                        <img src="img/unilorinpresi.png" class="img-responsive tm-media-img">
                        <div class="media-body tm-box-5">
                            <h5>Chapter President (Unilorin)</h5>
                            <p class="mb-0">...</p>
                        </div>
                    </div>
                    <div class="media tm-media">
                        <img src="img/KWASUPRESI.png" class="img-responsive tm-media-img">
                        <div class="media-body tm-box-5">
                            <h5>Chapter President (Kwasu)</h5>
                            <p class="mb-0">...</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="tm-section-6" id="tm-section-6">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-xs-12">
                    <div class="contact_message">
                        <form method="POST" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="row mb-2">
                                <div class="form-group col-xl-6">
                                    <input type="text" id="contact_name" name="ClientName" class="form-control"
                                        placeholder="Name" required />
                                </div>
                                <div class="form-group col-xl-6 pl-xl-1">
                                    <input type="email" id="contact_email" name="ClientEmail" class="form-control"
                                        placeholder="Email" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <textarea id="contact_message" name="ClientMessage" class="form-control" rows="6"
                                    placeholder="Message" required></textarea>
                            </div>
                            <button type="submit" class="btn  tm-btn-submit float-right btn-big"><i
                                    class="fa fa-envelope"></i> Send It Now</button>
                        </form>
                    </div>
                </div>

                <div class="col-lg-5 col-md-5 col-xs-12 tm-contact-right">
                    <div class="tm-address-box">
                        <h2 class="mb-4">Contact Us</h2>
                        <p class="mb-5">AYEDUN OKE-ERO KWARA STATE.</p>
                        <address>
                            <strong> Phones</strong>
                            <br><i style="font-size: 20px;" class="fa fa-phone"> +123 814 368 6809 &nbsp;&nbsp; National
                                PRO</i>,
                            <br> <i style="font-size: 20px;" class="fa fa-phone"> +123 813 452 2741 &nbsp;&nbsp;
                                National President</i>,
                        </address>
                    </div>
                </div>
            </div>
        </section>
        <footer class="mt-5">
            <p class="text-center">Copyright © 2020 Ayedun Students' Union - Design: CapeTech & Communications Inc </p>
        </footer>
    </div>

    <!-- load JS files -->
    <script type="/text/javascript" src="<?php echo e(asset('jquery-1.11.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <!-- https://popper.js.org/ -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- https://getbootstrap.com/ -->
    <script type="text/javascript" src="<?php echo e(asset('slick/slick.min.js')); ?>"></script>
    <!-- Slick Carousel -->

    <script>
        function setCarousel() {
            var slider = $('.tm-img-slider');

            if (slider.hasClass('slick-initialized')) {
                slider.slick('destroy');
            }

            if ($(window).width() > 991) {
                // Slick carousel
                slider.slick({
                    autoplay: true,
                    fade: true,
                    speed: 800,
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1
                });
            } else {
                slider.slick({
                    autoplay: true,
                    fade: true,
                    speed: 800,
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1
                });
            }
        }

        $(document).ready(function () {
            if (renderPage) {
                $('body').addClass('loaded');
            }

            setCarousel();

            $(window).resize(function () {
                setCarousel();
            });

            // Close menu after link click
            $('.nav-link').click(function () {
                $('#mainNav').removeClass('show');
            });

            // https://css-tricks.com/snippets/jquery/smooth-scrolling/
            // Select all links with hashes
            $('a[href*="#"]')
                // Remove links that don't actually link to anything
                .not('[href="#"]')
                .not('[href="#0"]')
                .click(function (event) {
                    // On-page links
                    if (
                        location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '')
                        &&
                        location.hostname == this.hostname
                    ) {
                        // Figure out element to scroll to
                        var target = $(this.hash);
                        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                        // Does a scroll target exist?
                        if (target.length) {
                            // Only prevent default if animation is actually gonna happen
                            event.preventDefault();
                            $('html, body').animate({
                                scrollTop: target.offset().top + 1
                            }, 1000, function () {
                                // Callback after animation
                                // Must change focus!
                                var $target = $(target);
                                $target.focus();
                                if ($target.is(":focus")) { // Checking if the target was focused
                                    return false;
                                } else {
                                    $target.attr('tabindex', '-1'); // Adding tabindex for elements not focusable
                                    $target.focus(); // Set focus again
                                };
                            });
                        }
                    }
                });
        });
    </script>

</body>

</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/index.blade.php ENDPATH**/ ?>
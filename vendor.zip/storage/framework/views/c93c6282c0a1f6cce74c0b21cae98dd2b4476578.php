<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User | Dashboard</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        .card:hover {
            box-shadow: 0px 2px 7px 2px gray;
        }

        body {
            font-family: Arial;
        }

    </style>
</head>

<body style="padding-top: 100px">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
            </div>
            <div class="col-sm-6">
                <form method="POST" action="<?php echo e(url('user/image-upload')); ?>" id="logout" novalidate>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary"> <a
                            style="color: white; text-decoration:none" href="/user/image-upload"> Upload Profile
                            Picture</a></button>
                </form>
                <form method="POST" action="<?php echo e(url('user/logout')); ?>" id="logout" novalidate>
                    <?php echo csrf_field(); ?>
                    <button style=" float: right;" type="submit" class="btn btn-sm btn-primary">Log Out</button>
                </form>
            </div>
        </div>
        <div class="row mt-12">
            <div class="col-md-12 offset-col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">USER PROFILE</h4>
                    </div>

                    <div class="card-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <span><?php echo e(session('success')); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('danger')): ?>
                            <div class="alert alert-danger">
                                <span><?php echo e(session('danger')); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <section class="blog-page">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 col-md-offset-2">
                                                <div class="blog-item">
                                                    <div>
                                                        <span style="float: left"
                                                            class="badge badge-info pull-right">Account Active since
                                                            <?php echo e(Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?>

                                                        </span><br>
                                                    </div>
                                                    <div class="down-content">

                                                        <div class="row">
                                                            <details>
                                                                <summary style="background-color:red; color:#fff;">
                                                                    ...See <i class="fa fa-eye"></i>
                                                                    <?php if($user->username == $UserId->username): ?>
                                                                        You About info
                                                                    <?php else: ?> <?php echo e($UserId->fullname); ?>

                                                                        About info
                                                                    <?php endif; ?>
                                                                </summary>
                                                                <table class="table"
                                                                    style="padding-left: 20px; margin-left: 30px;">
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            <img src="<?php echo e(asset($UserId->picture)); ?>"
                                                                                class="img-thumbnail" width="100px"
                                                                                width="100px"
                                                                                style="box-shadow: 0px 2px 7px 2px gray ;"
                                                                                alt="Ayedun Students' Union" />
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            ID NUMBER:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->id_number); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            FULL NAME:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->fullname); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            USER NAME:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->username); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            EMAIL:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->email); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            GENDER:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->gender); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            DATE OF BIRTH:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->date_of_birth); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            COMPOUND:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->compound); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>
                                                                            SCHOOL:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->institution); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            PLACE OF RESIDENCE:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->place_of_residence); ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>
                                                                            MARITAL STATUS:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->marital_status); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>
                                                                            PHONE NUMBER:
                                                                        </th>
                                                                        <td>
                                                                            <?php echo e($UserId->phone); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            <?php if($user->username == $UserId->username): ?>
                                                                                <button class="btn btn-info" style="float: right; background-color: #4CAF50;
                   color: white;
                   padding: 14px 20px;
                   margin: 8px 0;
                   border: none;
                   cursor: pointer;
                   width: 100%;"> <a style="text-decoration: none; color: #fff; "
                                                                                        href=<?php echo e(url('user/Edit_profile')); ?>>Edit/Update</a></button>
                                                                            <?php else: ?>

                                                                                <button class="btn btn-info" style="float: right; background-color: #4CAF50;
                                                  color: white;
                                                  padding: 14px 20px;
                                                  margin: 8px 0;
                                                  border: none;
                                                  cursor: pointer;
                                                  width: 100%;"> <a style="text-decoration: none; color: #fff; "
                                                                                        href=<?php echo e(url('user/home')); ?>>GO
                                                                                        HOME</a></button>
                                                                            <?php endif; ?>

                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                                </table>
                                                            </details>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-sm-6">
                            </div>
                        </div>
                    </div>
                </div>



                <div class="row">

                    <div class="col-lg-12 col-md-12" style="padding: 20px;">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title pull-left text-uppercase text-info font-weight-bolder">
                                    <?php echo e(strtoupper($UserId->username)); ?>'S POSTS</h3>
                                <h3 class="pull-right"><a class="btn btn-primary btn-sm"
                                        href="/school/students/register"><i class="fa fa-envelope"></i> Send Message
                                    </a> <a href="javascript:void(0)" onclick="window.history.back();"
                                        class="btn btn-info">Go Back</a></h3>
                            </div>
                            <div class="card-body">
                                <div class="row el-element-overlay">
                                    <?php $__currentLoopData = $All_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><br />
                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="card bg-white card-hover"  style=" 10px; margin-top: 10px">
                                                <div class="card-header">
                                                    <?php if($user->id == $item->userId): ?>
                                                        <a title="Click to Delete"  onclick="return confirm('Are you sure you want to delete this <?php echo e($item->username); ?>?')"
                                                            href="<?php echo e(url('user/delete_my_post/' . $item->id)); ?>">
                                                            <button id="delete-btn" value="0329/133"
                                                                class="btn btn-outline-danger btn-sm">
                                                                <i class="fa fa-trash font-weight-bolder"></i>
                                                            </button>
                                                        </a>
                                                        <a title="Click to Edit"
                                                            href="<?php echo e(url('user/editPost/' . $item->id)); ?>">
                                                            <button id="edit-btn" value="0329/133"
                                                                class="btn btn-outline-info btn-sm">
                                                                <i class="fa fa-edit font-weight-bolder"></i>
                                                            </button>
                                                        </a>
                                                    <?php endif; ?>
                                                    <span class="badge badge-success pull-right">
                                                        <?php echo e(strtoupper($item->username)); ?>

                                                </div>
                                               
                                                    <div class="card-title"
                                                        style="  height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">

                                                        <p>

                                                            <?php if($item->video == '' && $item->image == ''): ?>
                                                                <?php echo $item->posting; ?>

                                                            <?php elseif($item->posting =='' && $item->video==''): ?>
                                                                <img src="<?php echo e(asset($item->image)); ?>"
                                                                    class="img-thumbnail" width="100%" height="190%" />

                                                                <p>
                                                                    <?php echo $item->ImageCaption; ?>

                                                                </p>
                                                            <?php elseif($item->posting =='' && $item->image ==''): ?>
															<video width="100%" height="100%" controls>
																<source src="<?php echo e(asset($item->video)); ?>" type="video/mp4">
															</video>
															<p
															style="height: 50%; width: 100%; text-align: justify; color: black; font-family: Arial, Helvetica, sans-serif;">
															<?php echo $item->VideoCaption; ?>

														</p>
                                                            <?php endif; ?>
                                                        </p>

                                                    </div>
                                                  
                                               
                                                <div class="card-footer">
                                                    <?php
                                                        $isLiked = $item->likes
                                                            ->whereIn('post_id', [$item->id])
                                                            ->whereIn('user_id', [$user->id])
                                                            ->count();
                                                    ?>

                                                    <?php if($isLiked): ?>
                                                        <a title="Click to Like"
                                                            href="<?php echo e(url('user/like/' . $item->id)); ?>"
                                                            class="btn btn-primary btn-sm pull-left">
                                                            <i class="fa fa-thumbs-up"></i>
                                                            <span><?php echo e($item->likes->count()); ?></span>
                                                        </a>
                                                    <?php else: ?>
                                                        <a title="Click to Unlike"
                                                            href="<?php echo e(url('user/unlike/' . $item->id)); ?>"
                                                            class="btn btn-inverse btn-sm pull-left">
                                                            <i class="fa fa-thumbs-up"></i>
                                                            <span><?php echo e($item->likes->count()); ?></span>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a title="Click to See likers" href="<?php echo e(url('user/viewPostLikers/' . $item->id)); ?>"
                                                        class="btn btn-outline-success btn-sm pull-left">
                                                        <i class="fa fa-eye"></i>
                                                       
                                                    </a>
                                                    <a title="Click to comment"
                                                        href="<?php echo e(url('user/commentPage/' . $user->id)); ?>"
                                                        class="btn btn-outline-info btn-sm pull-left">
                                                        <i class="fa fa-comments"></i>
                                                    </a>

                                                    <a href="<?php echo e(url('user/view_user_profile/' . $user->id)); ?>"
                                                        class="btn btn-primary btn-sm pull-right">
                                                        PROFILE
                                                    </a>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="card card-body bg-transparent">
                                    <?php echo e($All_post->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->

    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <script>
        function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();

    </script>
</body>

</html>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/view_user_profile.blade.php ENDPATH**/ ?>
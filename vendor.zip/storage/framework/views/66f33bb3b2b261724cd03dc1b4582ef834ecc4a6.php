<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row mt-5">
            <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <div class="col-md-5 offset-col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">LOG IN</h4>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <span><?php echo e(session('success')); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <span><?php echo e(session('error')); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                <label for="email">Email</label>
                                <input type="text" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" id="password">
                                <?php if($errors->has('password')): ?>
                                    <span class="font-weight-bold"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                           
                            <button type="link" class="btn btn-primary">Log in</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/AdminLogin.blade.php ENDPATH**/ ?>
<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(now()->year); ?> <a href="https://www.ayedunstudentsunion.com">Ayedun Student's Union</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 4.1.0
    </div>
  </footer>
<?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>
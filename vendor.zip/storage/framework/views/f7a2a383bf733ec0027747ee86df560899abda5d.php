<!DOCTYPE html>
<html>
<head>
    <title>laravel 8 image upload example - ItSolutionStuff.com.com</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
    
<body>
<div class="container">
     
    <div class="panel panel-primary">
        <div class="panel-heading"><h2>Upload Your Image</h2></div>
        <div class="panel-body">
        
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e(session('success')); ?></strong>
                </div>
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e(session('error')); ?></strong>
                </div>
            <?php endif; ?> 
        
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?> 
            <form method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <input type="file" name="image" class="form-control">
                    </div>
        
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-success">Upload</button>
                        </div>
                    </div><br><a href="<?php echo e(url('user/home')); ?>" class="btn btn-outline-success"> Go Home </a>
                </div>
            </form>
       
    </div>
</div>
</body>
  
</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/imageUpload.blade.php ENDPATH**/ ?>
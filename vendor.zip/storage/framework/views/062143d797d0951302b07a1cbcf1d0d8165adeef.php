<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .help-block {
            color: #dc3545;
        }

        .has-error {
            color: #dc3545;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
            color: green;
        }

        .valid:before {
            position: relative;
            left: -20px;
            content: "✔";
        }

        /* Add a red text color and an "x" when the requirements are wrong */
        .invalid {
            color: red;
        }

        .invalid:before {
            position: relative;
            left: -20px;
            content: "✖";
        }
    </style>
</head>

<body style="padding-top: 70px">
    <div class="container">
        <div class="row mt-12">
            <div class="col-md-12 offset-col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><img style="border-radius: 100px; " src="img/ASU_LOGO.png" height="50"
                                width="60" class="img-responsive" alt="ASU logo" class="img-rounded">Registration Form
                        </h4><strong style="color: red">Note!
                             <i>* This Reg. Page is Strictly For None Indigene/None
                                Student only</i><br>
                                <i>* System would automatically suspend any ungenuine account </i>
                           </strong>
                    </div>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form method="POST" onSubmit="return checkPassword(this)" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group <?php echo e($errors->has('ID_NUMBER') ? 'has-error' : ''); ?>">
                                        <label for="ID_NUMBER">ID Number</label>
                                        <input type="text" name="ID_NUMBER" id="ID_NUMBER" class="form-control"
                                            value="<?php echo e('ASU'.Time().'@40'); ?>" readonly>
                                        <?php if($errors->has('ID_NUMBER')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('ID_NUMBER')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('stakeholder') ? 'has-error' : ''); ?>">
                                        <input type="text" name="guest" id="stakeholder" class="form-control" value="<?php echo e("
                                            GUEST"); ?>" readonly>
                                        <?php if($errors->has('stakeholder')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('stakeholder')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('fullname') ? 'has-error' : ''); ?>">
                                        <label for="fullname">Fullname</label>
                                        <input type="text" name="fullname" id="fullname" class="form-control"
                                            value="<?php echo e(old('fullname')); ?>" placeholder="Enter Your Full Name">
                                        <?php if($errors->has('fullname')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('fullname')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                        <label for="email" class="form-label">Email address</label>
                                        <input type="email" name="email" class="form-control" id="email"
                                            value="<?php echo e(old('email')); ?>" placeholder="Enter Your Address">
                                        <?php if($errors->has('email')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
                                        <label for="username">Username</label>
                                        <input type="text" name="username" id="username" class="form-control"
                                            value="<?php echo e(old('username')); ?>" placeholder="Enter Your UserName">
                                        <?php if($errors->has('username')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('username')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- ADDITIONAL FILEDS STARTS HERE-->

                                    <div class="form-group <?php echo e($errors->has('date_of_birth') ? 'has-error' : ''); ?>">
                                        <label for="date_of_birth">Date Of Birth</label>
                                        <input type="date" name="date_of_birth" id="date_of_birth" class="form-control"
                                            value="<?php echo e(old('date_of_birth')); ?>">
                                        <?php if($errors->has('date_of_birth')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('date_of_birth')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group <?php echo e($errors->has('compound') ? 'has-error' : ''); ?>">
                                        <label for="compound">Compound <i style="color: red">[Optional] Select <strong> GUEST</strong> if not indigene!</i></label>
                                        <select type="text" name="compound" id="compound" class="form-control"
                                            value="<?php echo e(old('compound')); ?>">
                                            <option value="">...Select...</option>
                                            <?php $__currentLoopData = $getCompound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value=" <?php echo e($compound ->Name_of_Compound); ?>"> <?php echo e($compound
                                                ->Name_of_Compound); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($errors->has('compound')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('compound')); ?></span>
                                            <?php endif; ?>
                                        </select>
                                    </div>


                                    <div class="form-group <?php echo e($errors->has('institution') ? 'has-error' : ''); ?>">
                                        <label for="institution">Institution</label>
                                        <select type="text" name="institution" id="institution" class="form-control"
                                            value="<?php echo e(old('institution')); ?>">
                                            <option value="">...Select...</option>
                                            <?php $__currentLoopData = $listOfSchools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listOfSchool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value=" <?php echo e($listOfSchool ->ListSchools); ?>"> <?php echo e($listOfSchool
                                                ->ListSchools); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($errors->has('institution')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('institution')); ?></span>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('place_of_residence') ? 'has-error' : ''); ?>">
                                        <label for="place_of_residence">Place Of Residence</label>
                                        <input type="text" name="place_of_residence" id="place_of_residence"
                                            class="form-control" value="<?php echo e(old('place_of_residence')); ?>">
                                        <?php if($errors->has('place_of_residence')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('place_of_residence')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('marital_status') ? 'has-error' : ''); ?>">
                                        <label for="marital_status">Marital Status</label>
                                        <select type="text" name="marital_status" id="marital_status"
                                            class="form-control" value="<?php echo e(old('marital_status')); ?>">
                                            <option value="">...Select...</option>
                                            <option value="Married">Married</option>
                                            <option value="Single">Single</option>
                                            <option value="Divorce">Divorce</option>
                                            <option value="Can't Say">Can't Say</option>
                                            <?php if($errors->has('marital_status')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('marital_status')); ?></span>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                        <label for="address">Address</label>
                                        <input type="tex" name="address" id="address" class="form-control"
                                            value="<?php echo e(old('address')); ?>"
                                            placeholder="Enter Address E.g 5, Ilupeju lagos" >
                                            <?php if($errors->has('address')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('address')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group <?php echo e($errors->has('security_question') ? 'has-error' : ''); ?>">
                                        <label for="security_question">Security Question</label>
                                        <select type="text" name="security_question" id="security_question"
                                            class="form-control" value="<?php echo e(old('security_question')); ?>">
                                            <option value="">...Select...</option>
                                            <option value="What is your mother's name">What is your mother's name
                                            </option>
                                            <option value="What was your childhood nickname">What was your childhood
                                                nickname</option>
                                            <option value="What is your street name">What is your street name</option>
                                            <option value="What is your favorite food">What is your favorite food
                                            </option>
                                            <option value="What age you got married">What age you got married</option>

                                            <?php if($errors->has('security_question')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('security_question')); ?></span>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('answers') ? 'has-error' : ''); ?>">
                                        <label for="answers">Answers</label>
                                        <input type="text" name="answers" id="answers" class="form-control"
                                            value="<?php echo e(old('answers')); ?>" placeholder="Enter Your Current Address">
                                        <?php if($errors->has('answers')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('answers')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                        <label for="text">Phone</label>
                                        <input type="number" name="phone" id="phone" class="form-control"
                                            value="<?php echo e(old('phone')); ?>" placeholder="Enter Your Active Phone">
                                        <?php if($errors->has('phone')): ?>
                                        <span class="font-weight-bold"><?php echo e($errors->first('phone')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- ADDITIONAL FILEDS ENDS HERE -->
                                    <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                                        <label for="gender">Gender</label>
                                        <select type="text" name="gender" id="gender" class="form-control"
                                            value="<?php echo e(old('gender')); ?>">
                                            <option value="">...Select...</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>

                                            <?php if($errors->has('gender')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('gender')); ?></span>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div id="message1"
                                        style="background-color: rgba(236, 228, 228, 0.479); font-size:10px">
                                        <h6 style="color: red">Password must contain the following:</h6>
                                        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                        <p id="number" class="invalid">A <b>number</b></p>
                                        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                        <label class="control-label" for="password"><i
                                                class="fa fa-lock"></i>Password:</label>
                                        <div>
                                            <input type="password" class="form-control" id="myInput1" name="password1"
                                                placeholder="Enter Password"
                                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                                title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                                            <input type="checkbox" onclick="myFunction()"> Show Password
                                            <?php if($errors->has('password')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div id="message2"
                                        style="background-color: rgba(236, 228, 228, 0.479); font-size:10px">
                                        <h6 style="color: red">Password must contain the following:</h6>
                                        <p id="letter2" class="invalid">A <b>lowercase</b> letter</p>
                                        <p id="capital2" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                        <p id="number2" class="invalid">A <b>number</b></p>
                                        <p id="length2" class="invalid">Minimum <b>8 characters</b></p>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                        <label class="control-label" for="password"><i
                                                class="fa fa-lock"></i>Password:</label>
                                        <div>
                                            <input type="password" class="form-control" id="myInput2" name="password"
                                                placeholder="Enter Password"
                                                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                                title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                                            <input type="checkbox" onclick="myFunction2()"> Show Password
                                            <?php if($errors->has('password')): ?>
                                            <span class="font-weight-bold"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-outline-primary btn-lg btn-block"
                                        onclick="matchPassword()">Submit</button>
                                    <button class="btn btn-outline-info" style="float: right; background-color: #4CAF50;
                                                  color: white;
                                                  padding: 14px 20px;
                                                  margin: 8px 0;
                                                  border: none;
                                                  cursor: pointer;
                                                  width: 100%;"> <a style="text-decoration: none; color: #fff; "
                                            href=<?php echo e(url('/')); ?>>GO HOME</a></button>
                                    <button style=" float: right;" type="submit"
                                        class="btn btn-outline-primary btn-lg btn-block"><a
                                            style="text-decoration: none; color:rgb(49, 4, 248);"
                                            href="<?php echo e(('/login')); ?>">Login</a></button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!--  // Second password1 fild-->
<script>
    var password1 = document.getElementById("myInput1");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");



    // When the user clicks on the password field, show the message box
    password1.onfocus = function () {
        document.getElementById("message1").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    password1.onblur = function () {
        document.getElementById("message1").style.display = "none";
    }

    // When the user starts to type something inside the password field
    password1.onkeyup = function () {
        // Validate lowercase letters
        var lowerCaseLetters = /[a-z]/g;
        if (password1.value.match(lowerCaseLetters)) {
            letter.classList.remove("invalid");
            letter.classList.add("valid");
        } else {
            letter.classList.remove("valid");
            letter.classList.add("invalid");
        }

        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if (password1.value.match(upperCaseLetters)) {
            capital.classList.remove("invalid");
            capital.classList.add("valid");
        } else {
            capital.classList.remove("valid");
            capital.classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if (password1.value.match(numbers)) {
            number.classList.remove("invalid");
            number.classList.add("valid");
        } else {
            number.classList.remove("valid");
            number.classList.add("invalid");
        }

        // Validate length
        if (password1.value.length >= 8) {
            length.classList.remove("invalid");
            length.classList.add("valid");
        } else {
            length.classList.remove("valid");
            length.classList.add("invalid");
        }
    }
</script>

<script>
    function myFunction() {
        var x = document.getElementById("myInput1");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>

<!--  // Second password1 fild-->
<script>
    var password2 = document.getElementById("myInput2");
    var letter2 = document.getElementById("letter2");
    var capital2 = document.getElementById("capital2");
    var number2 = document.getElementById("number2");
    var length2 = document.getElementById("length2");



    // When the user clicks on the password field, show the message box
    password2.onfocus = function () {
        document.getElementById("message2").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    password2.onblur = function () {
        document.getElementById("message2").style.display = "none";
    }

    // When the user starts to type something inside the password field
    password2.onkeyup = function () {
        // Validate lowercase letters
        var lowerCaseLetters = /[a-z]/g;
        if (password2.value.match(lowerCaseLetters)) {
            letter2.classList.remove("invalid");
            letter2.classList.add("valid");
        } else {
            letter2.classList.remove("valid");
            letter2.classList.add("invalid");
        }

        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if (password2.value.match(upperCaseLetters)) {
            capital2.classList.remove("invalid");
            capital2.classList.add("valid");
        } else {
            capital2.classList.remove("valid");
            capital2.classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if (password2.value.match(numbers)) {
            number2.classList.remove("invalid");
            number2.classList.add("valid");
        } else {
            number2.classList.remove("valid");
            number2.classList.add("invalid");
        }

        // Validate length
        if (password2.value.length >= 8) {
            length2.classList.remove("invalid");
            length2.classList.add("valid");
        } else {
            length2.classList.remove("valid");
            length2.classList.add("invalid");
        }
    }
</script>
<script>
    function myFunction2() {
        var x = document.getElementById("myInput2");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
<script>
    function checkPassword(form) {
        password1 = form.password1.value;
        password = form.password.value;

        // If password not entered 
        if (password1 == '')
            alert("Please enter Password");

        // If confirm password not entered 
        else if (password == '')
            alert("Please enter confirm password");

        // If Not same return False.     
        else if (password1 != password) {
            alert("\nPassword did not match: Please try again...")
            return false;
        }

        // If same return True. 
        else {
            alert("Password Match: Please keep it safe!")
            return true;
        }
    }
</script>

</html><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/registrationGuest.blade.php ENDPATH**/ ?>
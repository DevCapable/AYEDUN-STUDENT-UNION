<a style="text-decoration: none; color: red; float: right;" href="#" >Top Page</a>
<footer style="background-color: #ccffe6;">
    <div class="container" >
        <div class="row">
            <div class="col-md-4">
                <strong>Copyright &copy; <?php echo e(now()->year); ?> <a href="https://www.ayedunstudentsunion.com">Ayedun Student's Union</a>. <br></strong>
                All rights reserved.
                <div class="float-right d-none d-sm-inline-block">
                  <b>Version</b> 4.1.0
                </div>
            </div>
            <div class="col-md-4">
                <ul >
                    <li class="nav-item"><a class="nav-link" href="https://twitter.com/MrCapable22"><i id="twitterb" class="fab fa-twitter"></i></a></li>

            <li class="nav-item"><a class="nav-link" href="https://web.facebook.com/abdulrasaqolawale.olabode/about_details "><i id="facebookb"class="fab fa-facebook"></i></a></li>
            
            <li class="nav-item"><a class="nav-link" href="https://www.linkedin.com/in/dada-abdulrasaq-3b20871a2/"><i id="linkedinb" class="fab fa-linkedin"></i></a></li>
            <li class="nav-item"><a class="nav-link" href="http/www.google.com/ honcapable@gmail.com"><i id="googleb" class="fab fa-google-plus"></i></a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <strong>Designed by: CapeTech Inc  <a href="https://web.facebook.com/abdulrasaqolawale.olabode/about_details">Designed by: CapeTech Inc</a>. <br></strong>
               
                <div class="float-right d-none d-sm-inline-block">  <i class="fa fa-phone"></i> 08162291993.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\HONCAPABLE\LARAVEL_PROJECT\firstapp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>